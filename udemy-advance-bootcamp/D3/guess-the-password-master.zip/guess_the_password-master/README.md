# Guess the Password

Simple browser game with an ES2015 refactor. Open `index.html` in the browser to play the game. 

If you'd like to see some ES2015 features in the JavaScript code (including `let`, `const`, arrow functions, and more), check out the `ES2015` branch.
